import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SupervisorDashboardComponent } from './supervisor-dashboard/supervisor-dashboard.component';
import { CreateUserComponent } from './create-user/create-user.component';
import { ManageUsersComponent } from './manage-users/manage-users.component';

const routes: Routes = [
  { path: '', redirectTo: '/supervisor-dashboard', pathMatch: 'full' },
  { path: 'supervisor-dashboard', component: SupervisorDashboardComponent },
  { path: 'create-user', component: CreateUserComponent },
  { path: 'manage-users', component: ManageUsersComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
