// user-management.service.ts

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})

export class UserManagementService {

  private apiUrl = 'http://example.com/api/users'; // Replace with your API endpoint

  constructor(private http: HttpClient) { }

  createUser(username: string, password: string) {
    const body = { username, password };
    return this.http.post(this.apiUrl, body);
  }
}
