import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module'; // Import AppRoutingModule
import { AppComponent } from './app.component';
import { SupervisorDashboardComponent } from './supervisor-dashboard/supervisor-dashboard.component';
import { CreateUserComponent } from './create-user/create-user.component';
import { ManageUsersComponent } from './manage-users/manage-users.component';
import { UserManagementService } from './services/user-management.service';


@NgModule({
  declarations: [
    AppComponent,
    SupervisorDashboardComponent,
    CreateUserComponent,
    ManageUsersComponent
  ],
  imports: [
    BrowserModule,
    FormsModule, // Add if using template-driven forms
    ReactiveFormsModule, // Add if using reactive forms
    HttpClientModule,
    AppRoutingModule // Include AppRoutingModule in imports
  ],
  providers: [UserManagementService],
  bootstrap: [AppComponent]
})
export class AppModule { }
