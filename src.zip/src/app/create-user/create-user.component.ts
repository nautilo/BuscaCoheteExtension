// create-user.component.ts

import { Component } from '@angular/core';
import { UserManagementService } from '../services/user-management.service';


@Component({
  selector: 'create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.css']
})
export class CreateUserComponent {

  constructor(private userService: UserManagementService) { }

  onSubmit(username: string, password: string) {
    this.userService.createUser(username, password).subscribe(
      (response) => {
        console.log('Usuario creado correctamente:', response);
        // Handle success
      },
      (error) => {
        console.error('Error al crear el usuario:', error);
        // Handle error
      }
    );
  }
}
